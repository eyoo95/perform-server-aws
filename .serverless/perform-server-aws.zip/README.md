# 공연조회 앱 서버 (뭐보러갈래)
내 주변 공연을 조회할 수 있으며 공연 후기를 남겨 공유할 수 있습니다.



## API 명세서

https://documenter.getpostman.com/view/21511142/VUxNQng4
